#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <ctime>
#include <vector>
#include <sstream>

#include "GameState.h"
#include "Server.h"
#include "Client.h"

#include "Player.h"
#include "Enemy.h"


/*

	Class that acts as the game engine.
	Wrapper class.

*/
class Game
{
private:
	sf::VideoMode videoMode;
	sf::RenderWindow* window;
	sf::Event sfmlEvent;
	bool endGame;

	sf::Clock dtClock;

	
	
	bool isHost = false;
	

	int pointsP1;
	int pointsP2;

	bool playerOneWins;
	bool playerTwoWins;

	bool playerOneDied;
	bool playerTwoDied;

	sf::Font font;
	sf::Text guiText;
	sf::Text guiText2;
	sf::Text playerOneWinsText;
	sf::Text playerTwoWinsText;
	sf::Text playerOneDiedText;
	sf::Text playerTwoDiedText;

	std::vector<Enemy> enemies;
	float spawnTimerMax;
	float spawnTimer;
	int maxEnemies;

	std::stack<State*> states;

	void initWindow();
	void initStates();
	void initVariables();
	void initFonts();
	void initText();

public:

	sf::Time dt;



	Player p;
	Player p2;
	//Constructors and Destructors
	Game();
	~Game();
	 
	std::unique_ptr<Server> mGameServer;
	std::unique_ptr<Client> mGameClient;

	//Accessors
	const bool& getEndGame() const;



	//Modifiers



	//Functions
	const bool running() const;
	const int randBallType() const;
	void spawnEnemies();
	

	void updateDT();
	void pollEvents();
	void updatePlayer();
	void updateCollision();
	void updateGui();
	void update();

	void renderGui(sf::RenderTarget* target);
	void render();

	void run();

	//new stuff


	int getPlayerID();
	void setPlayerID(int playerID);
	int pID = 0;
	
	void setPlayerPosition(sf::Vector2f position);
	void setEnemyPlayerPosition(sf::Vector2f position);
	sf::Vector2f getPlayerPosition();
	sf::Vector2f getPlayer2Position();



	bool selectNetworkState();
	void startNetworks();

	void initPlayer();
	void initPlayer2();

	bool isNotHost = true;


	sf::Vector2f Interpolate(const sf::Vector2f& pointA, const sf::Vector2f& pointB, float factor);
};

#endif