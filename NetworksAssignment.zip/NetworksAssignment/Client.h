#pragma once
#include "GameState.h"

class Game;

#include <iostream>
#include <ctime>
#include <vector>
#include <sstream>

#include "Player.h"

class Client
{
private:
	bool mConnected;
	sf::TcpSocket mSocket;
	sf::Time mTimeSinceLastPacket;
	sf::Time mClientTimeout;
	sf::Clock mTickClock;
	sf::Thread mThread;

	//thread 
	sf::Clock mClock;
	bool mListeningState;
	sf::FloatRect mBattleFieldRect;
	std::size_t mMaxConnectedPlayers;
	std::size_t mConnectedPlayers;
	//bool mConnected;
	bool mWaitingThreadEnd;
	sf::Time mClientTimeoutTime;

	void executionThread();
	void sendTick();


	struct RemotePeer
	{
		RemotePeer();

		sf::TcpSocket socket;
		sf::Time lastPacketTime;
		bool ready;
		bool timedOut;
	};
	typedef std::unique_ptr<RemotePeer> PeerPtr;
	PeerPtr mPeer;
	void handleIncomingPacket(RemotePeer& receivingPeer);









	Game* world;

	sf::Vector2f playerPosition;

	PlayerInfo clientPlayer;
	PlayerInfo serverPlayer;
public:
	Client(sf::IpAddress ip, unsigned short ServerPort, Game& game);
	virtual ~Client();

	//sf::Vector2f Game::Interpolate(const sf::Vector2f& pointA, const sf::Vector2f& pointB, float factor);
	void handlePacket(sf::Int32 packetType, sf::Packet& packet);
	bool update(sf::Time dt);

	
};

