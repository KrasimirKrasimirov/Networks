#include "Client.h"
#include "Game.h"





Client::Client(sf::IpAddress ip, unsigned short ServerPort, Game& game):
	mClientTimeout(sf::seconds(2.f)),
	mTimeSinceLastPacket(sf::seconds(0.f)),
	mThread(&Client::executionThread, this)
	, mMaxConnectedPlayers(1)
	, mPeer()
	, mConnectedPlayers(0)
	, mWaitingThreadEnd(false)
	, mListeningState(false)
	, mClientTimeoutTime(sf::seconds(3.f))
{
	


	std::cout << "client constructor" << std::endl;
	if (mSocket.connect(ip, ServerPort, sf::seconds(5.f)) == sf::TcpSocket::Done)
	{
		mConnected = true;
		std::cout << "client connected" << std::endl;

		world = &game;

		//run the game only if the client connects to a server, otherwise stop connection
		world->initPlayer();
		world->p.isHost = true;
		world->p.isNotHost = false;
		world->p.canMove = false;

		mThread.launch();
	}
	else
	{
		std::cout << "Connection to server unsuccessful, check if the server has been initiated. \n";
		mSocket.setBlocking(false);
	}
}

Client::~Client()
{
}

void Client::handlePacket(sf::Int32 packetType, sf::Packet & packet)
{
	switch (packetType)
	{
	case packetServer::UpdateClientState:
	{
		//sf::Vector2f playerPosition;

		

		packet >> playerPosition.x >> playerPosition.y; 

		
		//world->setPlayerPosition(playerPosition);	//THIS SHOULD BE RIGHT
		
	} break;
	}
}

bool Client::update(sf::Time dt)
{
	if (mConnected)
	{
		

		world->setPlayerPosition(world->Interpolate(world->getPlayerPosition(), playerPosition, 50.f * dt.asSeconds()));
		//world->setEnemyPlayerPosition(world->Interpolate(world->getPlayer2Position(), enemyPlayerPosition, 50.f * world->dt.asSeconds()));//not sure
		

		mTimeSinceLastPacket += dt;
	}

	return true;
}



void Client::executionThread()
{
	//setListening(true);

	sf::Time stepInterval = sf::seconds(1.f / 60.f);
	sf::Time stepTime = sf::Time::Zero;
	sf::Time tickInterval = sf::seconds(1.f / 20.f);
	sf::Time tickTime = sf::Time::Zero;
	sf::Clock stepClock, tickClock;

	while (!mWaitingThreadEnd)
	{
		handleIncomingPacket(*mPeer);
		//handleIncomingConnections();

		stepTime += stepClock.getElapsedTime();
		stepClock.restart();

		tickTime += tickClock.getElapsedTime();
		tickClock.restart();

		//Fixed update step
		while (stepTime >= stepInterval)
		{
			stepTime -= stepInterval;
		}

		//Fixed tick step
		while (tickTime >= tickInterval)
		{
			sendTick();
			tickTime -= tickInterval;
		}

		//Sleep to prevent server from consuming 100% CPU
		sf::sleep(sf::milliseconds(10));
	}
}

void Client::sendTick()
{
	if (mTickClock.getElapsedTime() > sf::seconds(1.f / 20.f))
	{
		sf::Packet positionUpdatePacket;
		positionUpdatePacket << static_cast<sf::Int32>(packetClient::PositionUpdate);
		//positionUpdatePacket << serverPlayer.position.x << serverPlayer.position.y;    //how it used to be
		positionUpdatePacket << world->getPlayer2Position().x << world->getPlayer2Position().y;   //test, i think it works?
		mSocket.send(positionUpdatePacket);
		mTickClock.restart();
	}
}

void Client::handleIncomingPacket(RemotePeer& receivingPeer)
{
	sf::Packet packet;
	if (mSocket.receive(packet) == sf::Socket::Done)
	{
		mTimeSinceLastPacket = sf::seconds(0.f);
		sf::Int32 packetType;
		packet >> packetType;
		handlePacket(packetType, packet);
	}
	else
	{
		//check for timeout with the server
		if (mTimeSinceLastPacket > mClientTimeout)
		{
			mConnected = false;
		}
	}
}