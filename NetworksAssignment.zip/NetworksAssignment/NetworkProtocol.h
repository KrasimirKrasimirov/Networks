#pragma once
#include <SFML/Graphics.hpp>

const unsigned short ServerPort = 5000;


//Structure to store information about current player state
struct PlayerInfo
{
	sf::Vector2f position;
	
};


namespace packetClient
{
	//Packets originated in the client

	enum PacketType
	{
		PlayerEvent,
		PlayerRealtimeChange,
		RequestCoopPartner,
		PositionUpdate,
		GameEvent,
		Quit
	};
}

namespace packetServer
{

	//Packets originated in the server
	enum PacketType
	{
		BroadcastMessage,
		SpawnSelf,
		InitialState,
		PlayerEvent,
		PlayerRealtimeChange,
		PlayerConnect,
		PlayerDisconnect,
		AcceptCoopPartner,
		SpawnEnemy,
		SpawnPickup,
		UpdateClientState,
		CollectiblesMapPositions,
		MissionSuccess
	};
}