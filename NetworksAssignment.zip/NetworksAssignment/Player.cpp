#include "Player.h"
#include <iostream>



void Player::initVariables()
{
	this->movementSpeed = 5.f;
	this->hpMax = 10;
	this->hp = hpMax;
}

void Player::initShape(sf::Color color)
{
	this->shape.setFillColor(color);
	this->shape.setSize(sf::Vector2f(50.f, 50.f));
	
}

Player::Player(float x, float y, int playerID)
{
	this->shape.setPosition(x, y);
	

	this->initVariables();
	//this->initShape();

	//new stuff
	this->playerID = playerID;
}


Player::~Player()
{

}

const sf::RectangleShape & Player::getShape() const
{
	return this->shape;
}


//Accessors
const int & Player::getHp() const
{
	return this->hp;
}

const int & Player::getHpMax() const
{
	return this->hpMax;
}

//Functions
void Player::takeDamage(const int damage)
{
	if (this->hp > 0)
		this->hp -= damage;

	if (this->hp < 0)
		this->hp = 0;
}

void Player::gainHealth(const int health)
{
	if (this->hp < this->hpMax)
		this->hp += health;

	if (this->hp > this->hpMax)
		this->hp = this->hpMax;
}

void Player::updateInput()
{
	/*
	//Keyboard input
	//Left
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		this->shape.move(-this->movementSpeed, 0.f);
	}
	//Right
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		this->shape.move(this->movementSpeed, 0.f);
	}
	//Up
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
		this->shape.move(0.f, -this->movementSpeed);
	}
	//Down
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		this->shape.move(0.f, this->movementSpeed);
	}
	*/
	//std::cout << "\n" << isHost << " --- " << isNotHost << "\n";
	//new stuff
	if (isHost && canMove)
	{
		//Keyboard input
		//Left
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		{
			this->shape.move(-this->movementSpeed, 0.f);
		}
		//Right
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		{
			this->shape.move(this->movementSpeed, 0.f);
		}
		//Up
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		{
			this->shape.move(0.f, -this->movementSpeed);
		}
		//Down
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		{
			this->shape.move(0.f, this->movementSpeed);
		}
	}
	else if (isNotHost && canMove)
	{
		//Keyboard input
		//Left
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
		{
			this->shape.move(-this->movementSpeed, 0.f);
		}
		//Right
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
		{
			this->shape.move(this->movementSpeed, 0.f);
		}
		//Up
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
		{
			this->shape.move(0.f, -this->movementSpeed);
		}
		//Down
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
		{
			this->shape.move(0.f, this->movementSpeed);
		}
	}

}

void Player::updateWindowBoundsCollision(const sf::RenderTarget * target)
{
	//Update bounds after every position change
	//Left
	if (this->shape.getGlobalBounds().left <= 0.f)
		this->shape.setPosition(0.f, this->shape.getGlobalBounds().top);
	//Right
	if (this->shape.getGlobalBounds().left + this->shape.getGlobalBounds().width >= target->getSize().x)
		this->shape.setPosition(target->getSize().x - this->shape.getGlobalBounds().width, this->shape.getGlobalBounds().top);
	//Top
	if (this->shape.getGlobalBounds().top <= 0.f)
		this->shape.setPosition(this->shape.getGlobalBounds().left, 0.f);
	//Bottom
	if (this->shape.getGlobalBounds().top + this->shape.getGlobalBounds().height >= target->getSize().y)
		this->shape.setPosition(this->shape.getGlobalBounds().left, target->getSize().y - this->shape.getGlobalBounds().height);


}

void Player::update(const sf::RenderTarget* target)
{
	this->updateInput();

	//Window bounds collision
	this->updateWindowBoundsCollision(target);
}

void Player::render(sf::RenderTarget * target)
{
	target->draw(this->shape);
}

void Player::setPlayerPosition(sf::Vector2f position)
{
	this->shape.setPosition(position.x, position.y);
}
