#include "Game.h"



void Game::initVariables()
{
	this->endGame = false;
	this->spawnTimerMax = 10.f;
	this->spawnTimer = this->spawnTimerMax;
	this->maxEnemies = 10;
	this->pointsP1 = 0;
	this->pointsP2 = 0;
}

void Game::initWindow()
{
	this->videoMode = sf::VideoMode(800, 600);
	sf::VideoMode window_bounds(800, 600);
	this->window = new sf::RenderWindow(this->videoMode, "Game", sf::Style::Close | sf::Style::Titlebar);
	this->window->setFramerateLimit(60);
}

void Game::initStates()
{
	this->states.push(new GameState(this->window));
}

void Game::initFonts()
{
	if (!this->font.loadFromFile("Dosis-Light.otf"))
	{
		std::cout << " ! ERROR::GAME::INITFONTS::COULD NOT LOAD FONT DOSIS-LIGHT" << "\n";
	}
}

void Game::initText()
{
	//GUI text init
	this->guiText.setFont(this->font);
	this->guiText.setFillColor(sf::Color::White);
	this->guiText.setCharacterSize(24);

	//GUI text init for player 2
	this->guiText2.setFont(this->font);
	this->guiText2.setFillColor(sf::Color::White);
	this->guiText2.setCharacterSize(24);
	this->guiText2.setPosition(sf::Vector2f(650, 0));

	//Player one wins text
	this->playerOneWinsText.setFont(this->font);
	this->playerOneWinsText.setFillColor(sf::Color::Red);
	this->playerOneWinsText.setCharacterSize(35);
	this->playerOneWinsText.setPosition(sf::Vector2f(20, 300));
	this->playerOneWinsText.setString("PPPPPlayer one reached 50 points first and won the game!");

	//Player two wins text
	this->playerTwoWinsText.setFont(this->font);
	this->playerTwoWinsText.setFillColor(sf::Color::Yellow);
	this->playerTwoWinsText.setCharacterSize(35);
	this->playerTwoWinsText.setPosition(sf::Vector2f(20, 300));
	this->playerTwoWinsText.setString("Player two reached 50 points first and won the game!");

	//Player one died text
	this->playerOneDiedText.setFont(this->font);
	this->playerOneDiedText.setFillColor(sf::Color::Yellow);
	this->playerOneDiedText.setCharacterSize(35);
	this->playerOneDiedText.setPosition(sf::Vector2f(20, 300));
	this->playerOneDiedText.setString("Player one's health dropped to 0 and died, p2 wins!");

	//Player two died text
	this->playerTwoDiedText.setFont(this->font);
	this->playerTwoDiedText.setFillColor(sf::Color::Red);
	this->playerTwoDiedText.setCharacterSize(35);
	this->playerTwoDiedText.setPosition(sf::Vector2f(20, 300));
	this->playerTwoDiedText.setString("Player two's health dropped to 0 and died, p1 wins!");
}

//Constructors and Destructors
Game::Game()
{
	this->initWindow();
	this->initStates();
}

Game::~Game()
{
	delete this->window;

	while (!this->states.empty())
	{
		delete this->states.top();
		this->states.pop();
	}
}

const bool & Game::getEndGame() const
{
	return this->endGame;
}



//Functions
const bool Game::running() const
{
	return this->window->isOpen() /*&& this->endGame == false*/;
}

void Game::updateDT()
{
	this->dt = this->dtClock.restart();
}

void Game::pollEvents()
{
	while (this->window->pollEvent(this->sfmlEvent)) 
	{
		switch (this->sfmlEvent.type)
		{
		case sf::Event::Closed:
			this->window->close();
			break;
		case sf::Event::KeyPressed:
			if (this->sfmlEvent.key.code == sf::Keyboard::Escape)
				this->window->close();
			break;
		}
	}
}



void Game::spawnEnemies()
{
	//Timer
	if (this->spawnTimer < this->spawnTimerMax)
	{
		this->spawnTimer += 1.f;
	}
	else
	{
		if(this->enemies.size() < this->maxEnemies)
		{ 
			this->enemies.push_back(Enemy(*this->window, this->randBallType()));
			this->spawnTimer = 0.f;
		}
	}
}

const int Game::randBallType() const
{
	int type = EnemyTypes::DEFAULT;
	int randValue = rand() % 100 + 1;
	if (randValue > 60 && randValue <= 80)
		type = EnemyTypes::DAMAGING;
	else if (randValue > 80 && randValue <= 100)
		type = EnemyTypes::HEALING;
	return type;
}

void Game::updatePlayer()
{
	p.update(this->window);

	if (p.getHp() <= 0)
	{
		this->endGame = true;
		playerOneDied = true;
		playerTwoDied = false;
	}

	p2.update(this->window);

	if (p2.getHp() <= 0)
	{
		this->endGame = true;
		playerOneDied = false;
		playerTwoDied = true;
	}
	
	if (pointsP1 >= 50 && pointsP2 < 50)
	{
		playerOneWins = true;
		playerTwoWins = false;
		this->endGame = true;
	}
	else if (pointsP1 < 50 && pointsP2 >= 50)
	{
		playerTwoWins = true;
		playerOneWins = false;
		this->endGame = true;
	}
}

void Game::updateCollision()
{
	//Check the collision
	for (size_t i = 0; i < this->enemies.size(); i++)
	{
		if (p.getShape().getGlobalBounds().intersects(this->enemies[i].getShape().getGlobalBounds()))
		{
			switch (this->enemies[i].getType())
			{
			case EnemyTypes::DEFAULT:
				//Add points
				this->pointsP1++;
				break;
			case EnemyTypes::DAMAGING:
				p.takeDamage(1);
				break;
			case EnemyTypes::HEALING:
				p.gainHealth(1);
				break;
			}
			//Remove the enemy
			this->enemies.erase(this->enemies.begin() + i);
		}

		else if (p2.getShape().getGlobalBounds().intersects(this->enemies[i].getShape().getGlobalBounds()))
		{
			switch (this->enemies[i].getType())
			{
			case EnemyTypes::DEFAULT:
				//Add points
				this->pointsP2++;
				break;
			case EnemyTypes::DAMAGING:
				p2.takeDamage(1);
				break;
			case EnemyTypes::HEALING:
				p2.gainHealth(1);
				break;
			}
			//Remove the enemy
			this->enemies.erase(this->enemies.begin() + i);
		}
	}
}

void Game::updateGui()
{
	std::stringstream ss;


	ss << "Player 1 " << "\n"
		<< "Points: " << this->pointsP1 << "/ 50" << "\n"
		<< "Health: " << p.getHp() << " / " << p.getHpMax() << "\n";


	this->guiText.setString(ss.str());


	std::stringstream ss2;


	ss2 << "Player 2 " << "\n" 
		<< "Points: " << this->pointsP2 << "/ 50" << "\n"
		<< "Health: " << p2.getHp() << " / " << p2.getHpMax() << "\n";


	this->guiText2.setString(ss2.str());
}

void Game::update()
{
	this->pollEvents();

	if(this->endGame == false)
	{ 
		this->spawnEnemies();
		this->updatePlayer();
		this->updateCollision();
		this->updateGui();
	}
}

void Game::renderGui(sf::RenderTarget* target)
{
	target->draw(this->guiText);
	target->draw(this->guiText2);
}

void Game::render()
{
	this->window->clear();


	if (!this->states.empty())
	{
		this->states.top()->render();
	}


	//Render stuff
	p.render(this->window);
	p2.render(this->window);

	for (auto i : this->enemies)
	{
		i.render(*this->window);
	}


	//Render Gui
	this->renderGui(this->window);

	//Render end text
	if (this->endGame && playerOneDied) //check if player one died
		this->window->draw(this->playerOneDiedText);
	else if (this->endGame && playerTwoDied) // check if player two died
		this->window->draw(this->playerTwoDiedText);
	else if (this->endGame && playerOneWins && !playerOneDied) // check if player one wins by reaching a score of 50
		this->window->draw(this->playerOneWinsText);
	else if (this->endGame && playerTwoWins && !playerTwoDied) //check if player two wins by reaching a score of 50
		this->window->draw(this->playerTwoWinsText);

	

	this->window->display();
}

void Game::run()
{
	this->initVariables();
	this->initFonts();
	this->initText();
	selectNetworkState();

	if(isHost){
	this->initPlayer();
	}
	if(isNotHost){
	this->initPlayer2();
	}
	//selectNetworkState();
	startNetworks();
	
	
	while (this->window->isOpen())
	{
		this->updateDT();
		this->update();
		this->render();

		if (isHost)
		{
			//server loop is other thread
			mGameServer->update(dt);
		}

		else
		{
			mGameClient->update(dt);
		}
		

	}
}



void Game::setPlayerPosition(sf::Vector2f position)
{
	this->p.setPlayerPosition(position);
}

void Game::setEnemyPlayerPosition(sf::Vector2f position)
{
	this->p2.setPlayerPosition(position);
}

sf::Vector2f Game::getPlayerPosition()
{
	return this->p.getShape().getPosition();
}

sf::Vector2f Game::getPlayer2Position()
{
	return this->p2.getShape().getPosition();
}

bool Game::selectNetworkState()
{
	std::string netState;
	std::cout << "Are you the server (S/s) or the Client (C/c)? \n";

	do
	{
		netState.clear();
		std::cin >> netState;
		if (netState == "s" || netState == "S")
		{
			isHost = true;
			isNotHost = false;
			return isHost;
			break;
		}
		else if (netState == "c" || netState == "C")
		{
			isHost = false;
			isNotHost = true;
			return isNotHost;
			break;
		}
		std::cout << "Invalid input, try again. \n";
	} while (true);
	std::cout << netState << " " << "Server = " << std::boolalpha << isHost
		<< std::noboolalpha << std::endl;

	return false;
}

void Game::startNetworks()
{
	sf::IpAddress ip;
	if (isHost)
	{
		//start server thread
		//Player1 = server player - pass this info
		//enemy player = client p2
		ip = "127.0.0.1";

		mGameServer.reset(new Server(ip, ServerPort, window->getSize(), *this));
	}
	else
	{
		//start client thread
		//Player2 = client player - pass this info
		//enemy player = server p1
		ip = "127.0.0.1";
		mGameClient.reset(new Client(ip, ServerPort, *this));
	}
}



//new stuff

int Game::getPlayerID()
{
	//TODO LATER UPDATE THIS FUNCTION FOR PLAYER 2
	return p.playerID;
}

void Game::setPlayerID(int playerID)
{
	//TODO LATER UPDATE THIS FUNCTION FOR PLAYER 2
	this->pID = playerID;
	p.playerID = playerID;
}

void Game::initPlayer()
{
	Player player(10.f, 20.f, this->pID);
	player.initVariables();
	
	player.initShape(sf::Color::Red);
	player.playerID = 1;
	player.isHost = this->isHost;
	player.isNotHost = this->isNotHost;
	player.canMove = true;
	this->p = player;
	

}
void Game::initPlayer2()
{
	Player player(500.f, 20.f, this->pID);
	player.initVariables();

	
	player.initShape(sf::Color::Yellow);
	player.playerID = 2;
	player.isHost = this->isHost;
	player.isNotHost = this->isNotHost;
	player.canMove = true;

	this->p2 = player;
}

sf::Vector2f Game::Interpolate(const sf::Vector2f & pointA, const sf::Vector2f & pointB, float factor)
{
	if (factor > 1.f)
		factor = 1.f;

	else if (factor < 0.f)
		factor = 0.f;

	return pointA + (pointB - pointA) * factor;
}



