#include <iostream>
#include "Enemy.h"




void Enemy::initShape(const sf::RenderWindow& window)
{
	this->shape.setRadius(static_cast<float>(rand()%10 + 10));
	
	sf::Color color;
	
	switch (this->type)
	{
	case DEFAULT:
		color = sf::Color(rand() % 255 + 1, rand() % 255 + 1, rand() % 255 + 1);
		break;
	case DAMAGING:
		color = sf::Color::Red;
		this->shape.setOutlineColor(sf::Color::White);
		this->shape.setOutlineThickness(2.f);
		break;
	case HEALING:
		color = sf::Color::Green;
		this->shape.setOutlineColor(sf::Color::White);
		this->shape.setOutlineThickness(2.f);
		break;
	}


	//sf::Color color(rand() % 255 + 1, rand() % 255 + 1, rand() % 255 + 1);
	this->shape.setFillColor(color);	

	float x = rand() % window.getSize().x - this->shape.getGlobalBounds().width;
	float y = rand() % window.getSize().y - this->shape.getGlobalBounds().height;

	//control the enemy to not go out of the borders of the screen
	if (x < 2)
		x = 2.f;

	if (y < 2)
		y = 2.f;

	if (x > window.getSize().x)
		x = window.getSize().x - this->shape.getGlobalBounds().width;

	if (y > window.getSize().y)
		y = window.getSize().y - this->shape.getGlobalBounds().height;

	//set the position of the enemy
	this->shape.setPosition(sf::Vector2f(static_cast<float>(x), static_cast<float>(y)));
	
	
	
	std::cout << x << ", "<< y << "\n";
}

Enemy::Enemy(const sf::RenderWindow& window, int type)
	:type(type)
{
	this->initShape(window);

	
}


Enemy::~Enemy()
{
}

const sf::CircleShape Enemy::getShape() const
{
	return this->shape;
}

const int & Enemy::getType() const
{
	return this->type;
}

void Enemy::update()
{
}

void Enemy::render(sf::RenderTarget & target)
{
	target.draw(this->shape);
}
